import { Component } from '@angular/core';

@Component({
  selector: 'app-afteradminlogin',
  templateUrl: './afteradminlogin.component.html',
  styleUrls: ['./afteradminlogin.component.css']
})
export class AfteradminloginComponent {

}
